from pygments.styles import get_all_styles
styles = list(get_all_styles())
print '\n'.join(styles)
