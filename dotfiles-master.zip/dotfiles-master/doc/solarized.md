# Solarized

- [Solarized](https://github.com/altercation/solarized)
- [Vim](http://ethanschoonover.com/solarized/vim-colors-solarized)
- [Vim - GitHub](https://github.com/altercation/solarized/tree/master/vim-colors-solarized)
- [tmux](https://github.com/altercation/solarized/tree/master/tmux)
- [Termianl.app](https://github.com/altercation/solarized/tree/master/osx-terminal.app-colors-solarized)
- [dircolors](https://github.com/seebi/dircolors-solarized)
- [Gnome Terminal](https://github.com/Anthony25/gnome-terminal-colors-solarized)
- [Pygments](http://www.realultimateprogramming.com/solarized-dark-pygments/)
- [Pygments light](https://github.com/john2x/solarized-pygment)

<!--vim:ft=markdown-->
